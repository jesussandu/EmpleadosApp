package com.example.empleados

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import com.example.empleados.ui.theme.EmpleadosTheme

class Pantalla1Honorarios : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
        Pantalla1()
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun Pantalla1(){
    val contexto= LocalContext.current
    Column(modifier=Modifier.fillMaxSize()){
    Button(onClick = {
        val intent = Intent(contexto, MainActivity::class.java)
        contexto.startActivity( intent )
    }) {
        Text(text = "Volver")
    }
    }
}
class empleadoHonorarios(){
    val sueldo = ()

}